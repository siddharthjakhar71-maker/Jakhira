import { AppLayout } from "@/components/layout/AppLayout";
import { useStore } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2, Upload, Eye } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useRef } from "react";
import * as XLSX from 'xlsx';

export default function Materials() {
  const { materials, addMaterial, updateMaterial, deleteMaterial, addMaterials, searchQuery } = useStore();
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', category: '', unit: '', defaultRate: '' });
  const [viewMaterial, setViewMaterial] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredMaterials = materials.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (m.category && m.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleOpenEdit = (m: any) => {
      setFormData({ name: m.name, category: m.category || '', unit: m.unit || '', defaultRate: m.defaultRate ? m.defaultRate.toString() : '' });
      setEditingId(m.id);
      setOpen(true);
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    
    const submitData = { ...formData, defaultRate: Number(formData.defaultRate) || 0 };
    
    if (editingId) {
        updateMaterial(editingId, submitData);
    } else {
        addMaterial(submitData);
    }
    
    setOpen(false);
    setEditingId(null);
    setFormData({ name: '', category: '', unit: '', defaultRate: '' });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws);
      
      const newMaterials = data.map((row: any) => ({
          name: row['Name'] || row['Material Name'] || row['Item'] || 'Unknown Item',
          category: row['Category'] || '',
          unit: row['Unit'] || row['UOM'] || '',
          defaultRate: Number(row['Default Rate'] || row['Rate'] || row['Price'] || 0)
      })).filter(m => m.name && m.name !== 'Unknown Item');
      
      if(newMaterials.length > 0) addMaterials(newMaterials);
    };
    reader.readAsBinaryString(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <AppLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Materials / Items</h1>
            <p className="text-sm text-muted-foreground">Manage your material catalog and default rates.</p>
          </div>
          <div className="flex gap-2">
            <input type="file" accept=".xlsx, .xls, .csv" className="hidden" ref={fileInputRef} onChange={handleFileUpload} />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} data-testid="button-import-materials">
              <Upload className="w-4 h-4 mr-2" /> Import
            </Button>
            <Dialog open={open} onOpenChange={(isOpen) => {
                setOpen(isOpen);
                if(!isOpen) {
                    setEditingId(null);
                    setFormData({ name: '', category: '', unit: '', defaultRate: '' });
                }
            }}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-material"><Plus className="w-4 h-4 mr-2" /> Add Material</Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingId ? 'Edit Material' : 'Add New Material'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-4">
                  <div className="grid gap-2">
                    <Label>Material Name *</Label>
                    <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} data-testid="input-material-name" />
                  </div>
                  <div className="grid gap-2">
                    <Label>Category (Optional)</Label>
                    <Input value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} data-testid="input-material-category" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label>Unit of Measurement (Optional)</Label>
                      <Input placeholder="e.g. Bags, Ton, Nos" value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})} data-testid="input-material-unit" />
                    </div>
                    <div className="grid gap-2">
                      <Label>Default Rate (₹) (Optional)</Label>
                      <Input type="number" value={formData.defaultRate} onChange={e => setFormData({...formData, defaultRate: e.target.value})} data-testid="input-material-rate" />
                    </div>
                  </div>
                  <Button type="submit" className="mt-2" data-testid="button-save-material">{editingId ? 'Update' : 'Save'} Material</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Material Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead className="text-right">Default Rate</TableHead>
                  <TableHead className="w-[100px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMaterials.map((item) => (
                  <TableRow key={item.id} data-testid={`row-material-${item.id}`}>
                    <TableCell className="font-medium" data-testid={`text-material-name-${item.id}`}>{item.name}</TableCell>
                    <TableCell>{item.category || '-'}</TableCell>
                    <TableCell>{item.unit || '-'}</TableCell>
                    <TableCell className="text-right">₹{(item.defaultRate || 0).toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => setViewMaterial(item)} data-testid={`button-view-material-${item.id}`}>
                                <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => handleOpenEdit(item)} data-testid={`button-edit-material-${item.id}`}>
                                <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => deleteMaterial(item.id)} data-testid={`button-delete-material-${item.id}`}>
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </div>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredMaterials.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">No materials found.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>


        <Dialog open={!!viewMaterial} onOpenChange={(open) => !open && setViewMaterial(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>Material Details</DialogTitle></DialogHeader>
            {viewMaterial && (
              <div className="space-y-2 text-sm">
                <p><strong>Name:</strong> {viewMaterial.name}</p>
                <p><strong>Category:</strong> {viewMaterial.category || '-'}</p>
                <p><strong>Unit:</strong> {viewMaterial.unit || '-'}</p>
                <p><strong>Default Rate:</strong> ₹{(viewMaterial.defaultRate || 0).toLocaleString()}</p>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
